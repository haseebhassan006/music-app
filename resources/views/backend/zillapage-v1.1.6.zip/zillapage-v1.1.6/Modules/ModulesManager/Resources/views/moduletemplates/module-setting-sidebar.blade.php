<a href="{{ route('settings.modulesmanager.index') }}" class="list-group-item list-group-item-action d-flex align-items-center">
    @lang('Modules Manager')
</a>