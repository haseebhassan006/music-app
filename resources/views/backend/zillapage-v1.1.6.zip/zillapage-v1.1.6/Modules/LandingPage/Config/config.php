<?php

return [
    'name' => 'LandingPage',
    'menu' => [
        'siderbar_position' => 2, // Need config !=0
    ],
];
