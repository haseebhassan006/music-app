<?php

return [
    'name' => 'Settings',
    'menu' => [
        'siderbar_setting_position' => 1, // Need config !=0
        'siderbar_position' => 1, // Need config !=0
    ],
];
