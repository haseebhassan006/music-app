<?php

return [
    'name' => 'Install'
];
