<a href="{{ route('settings.users.index') }}" class="list-group-item list-group-item-action d-flex align-items-center">
        @lang('Users')
</a>