<?php

return [
    'name' => 'User',
    'menu' => [
        'siderbar_setting_position' => 20,
    ],
];
