<?php

return [
    'name' => 'BlocksLandingPage',
    'menu' => [
        'siderbar_setting_position' => 7, // Need config !=0
    ],
];
