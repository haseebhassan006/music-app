<a href="{{ route('settings.blocks.index') }}" class="list-group-item list-group-item-action d-flex align-items-center">
	@lang('Blocks')
</a>
<a href="{{ route('settings.blockscategories.index') }}" class="list-group-item list-group-item-action d-flex align-items-center">
	@lang('Block Categories')
</a>