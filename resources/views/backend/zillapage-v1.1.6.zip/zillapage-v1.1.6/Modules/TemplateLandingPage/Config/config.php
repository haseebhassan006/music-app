<?php

return [
    'name' => 'TemplateLandingPage',
    'menu' => [
        'siderbar_setting_position' => 5, // Need config !=0
    ],
];
