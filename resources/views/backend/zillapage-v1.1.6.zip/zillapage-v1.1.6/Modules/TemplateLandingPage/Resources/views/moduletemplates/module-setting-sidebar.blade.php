<a href="{{ route('settings.templates.index') }}" class="list-group-item list-group-item-action d-flex align-items-center">
	@lang('Templates')
</a>
<a href="{{ route('settings.categories.index') }}" class="list-group-item list-group-item-action d-flex align-items-center">
	@lang('Template Categories')
</a>
<a href="{{ route('settings.groupcategories.index') }}" class="list-group-item list-group-item-action d-flex align-items-center">
	@lang('Group Categories')
</a>