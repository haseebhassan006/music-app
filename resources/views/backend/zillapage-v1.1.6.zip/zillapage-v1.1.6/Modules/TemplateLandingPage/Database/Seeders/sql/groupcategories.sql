INSERT INTO `group_categories` (`id`, `name`, `thumb`, `color`, `created_at`, `updated_at`) VALUES
(1, 'Landing Page Goals', '', NULL, '2021-02-22 21:16:07', '2021-02-22 21:16:07'),
(2, 'Industries', '', NULL, '2021-02-22 21:16:23', '2021-02-22 21:16:23');
