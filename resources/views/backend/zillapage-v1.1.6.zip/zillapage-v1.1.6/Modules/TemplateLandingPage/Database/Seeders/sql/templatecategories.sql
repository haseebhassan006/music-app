INSERT INTO `categories` (`id`, `name`, `thumb`, `color`, `created_at`, `updated_at`, `group_category_id`) VALUES
(1, 'Newsletter signup', NULL, NULL, '2020-10-03 17:25:19', '2021-02-22 21:18:00', 1),
(2, 'Event signup', NULL, NULL, '2020-11-23 08:25:16', '2021-02-22 21:17:57', 1),
(3, 'E-book download', '', NULL, '2021-02-22 21:17:52', '2021-02-22 21:17:52', 1);
