<?php

return [
    'name' => 'PagesWebsite',
    'menu' => [
        'siderbar_setting_position' => 6, // Need config !=0
        'bottom_skins_position' => 99,
    ],
];
