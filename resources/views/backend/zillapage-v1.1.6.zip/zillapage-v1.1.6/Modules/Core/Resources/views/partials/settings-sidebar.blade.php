<div class="list-group list-group-transparent mb-0">
    {!! menuAdminSettingSiderbar() !!}
</div>