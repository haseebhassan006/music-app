<?php

return [
    'name' => 'Ecommerce',
    'menu' => [
        'siderbar_position' => 3, // Need config !=0
        'account_payment_position' => 2,
    ],
];
