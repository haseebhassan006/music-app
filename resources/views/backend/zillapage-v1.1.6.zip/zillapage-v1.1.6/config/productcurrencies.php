<?php

return 
[
    "USD" => "($) United States dollar",
    "EUR" => "(£) Euro",
    "JPY" => "(¥) Japanese yen",
    "GBP" => "(£) Pound sterling",
    "BRL" => "(R$) Brazilian real",
    "PLN" => "(zł) Polish złoty",

];