<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\LandingPage\\Providers\\LandingPageServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\LandingPage\\Providers\\LandingPageServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);