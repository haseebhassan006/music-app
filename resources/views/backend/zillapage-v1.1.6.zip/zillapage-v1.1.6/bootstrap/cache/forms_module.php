<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Forms\\Providers\\FormsServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Forms\\Providers\\FormsServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);