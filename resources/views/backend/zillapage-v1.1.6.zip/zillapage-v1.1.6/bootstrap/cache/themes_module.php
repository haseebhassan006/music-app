<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Themes\\Providers\\ThemesServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Themes\\Providers\\ThemesServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);