<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Settings\\Providers\\SettingsServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Settings\\Providers\\SettingsServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);