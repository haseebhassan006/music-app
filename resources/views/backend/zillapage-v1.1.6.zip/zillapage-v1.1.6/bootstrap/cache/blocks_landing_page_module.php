<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\BlocksLandingPage\\Providers\\BlocksLandingPageServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\BlocksLandingPage\\Providers\\BlocksLandingPageServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);